﻿using MEDTIME.DataLayer.Context;
using MEDTIME.DataLayer.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MEDTIME.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AvailabilityController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AvailabilityController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllAvailabilities()
        {
            var availabilities = await _context.Availabilities
                .Include(a => a.Doctor)
                .ToListAsync();
            return Ok(availabilities);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetAvailability(int id)
        {
            var availability = await _context.Availabilities
                .Include(a => a.Doctor)
                .FirstOrDefaultAsync(a => a.AvailabilityId == id);

            if (availability == null)
                return NotFound();

            return Ok(availability);
        }

        [HttpPost]
        public async Task<IActionResult> CreateAvailability([FromBody] Availability availability)
        {
            if (availability == null)
                return BadRequest();

            _context.Availabilities.Add(availability);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetAvailability), new { id = availability.AvailabilityId }, availability);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAvailability(int id, [FromBody] Availability updatedAvailability)
        {
            if (id != updatedAvailability.AvailabilityId)
                return BadRequest();

            _context.Entry(updatedAvailability).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AvailabilityExists(id))
                    return NotFound();

                throw;
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAvailability(int id)
        {
            var availability = await _context.Availabilities.FindAsync(id);

            if (availability == null)
                return NotFound();

            _context.Availabilities.Remove(availability);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AvailabilityExists(int id)
        {
            return _context.Availabilities.Any(e => e.AvailabilityId == id);
        }
    }
}
