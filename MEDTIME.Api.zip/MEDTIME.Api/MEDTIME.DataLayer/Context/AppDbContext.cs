﻿
using Microsoft.EntityFrameworkCore;
using MEDTIME.DataLayer.Entities;

namespace MEDTIME.DataLayer.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Patient> Patients { get; set; }
        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Appointment> Appointments { get; set; }
        public DbSet<Specialty> Specialties { get; set; }
        public DbSet<Availability> Availabilities { get; set; }
    }
}
