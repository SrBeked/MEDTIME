﻿namespace MEDTIME.DataLayer.Entities
{
    public class Doctor
    {
        public int DoctorId { get; set; }
        public required string Name { get; set; }
        public required string Specialty { get; set; }
    }
}
