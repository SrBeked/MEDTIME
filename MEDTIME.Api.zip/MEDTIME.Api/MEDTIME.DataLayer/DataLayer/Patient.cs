﻿namespace MEDTIME.DataLayer.Entities
{
    public class Patient
    {
        public int PatientId { get; set; }
        public required string Name { get; set; }
        public required string Email { get; set; }
    }
}
