﻿namespace MEDTIME.DataLayer.Entities
{
    public class Specialty
    {
        public int SpecialtyId { get; set; }
        public required string Name { get; set; }
    }
}
