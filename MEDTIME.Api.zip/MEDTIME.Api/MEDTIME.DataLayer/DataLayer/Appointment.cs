﻿namespace MEDTIME.DataLayer.Entities
{
    public class Appointment
    {
        public int AppointmentId { get; set; }
        public int PatientId { get; set; }
        public int DoctorId { get; set; }
        public DateTime DateTime { get; set; }
        public required string Status { get; set; } // Scheduled, Cancelled, Completed

        // Relaciones
        public required Patient Patient { get; set; }
        public required Doctor Doctor { get; set; }
    }
}
