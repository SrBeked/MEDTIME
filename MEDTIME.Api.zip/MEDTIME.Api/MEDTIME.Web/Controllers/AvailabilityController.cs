﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MEDTIME.DataLayer;
using MEDTIME.DataLayer.Entities;
using MEDTIME.DataLayer.Context;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace MEDTIME.Web.Controllers
{
    public class AvailabilityController : Controller
    {
        private readonly AppDbContext _context;

        public AvailabilityController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var availabilities = _context.Availabilities.Include(a => a.Doctor);
            return View(await availabilities.ToListAsync());
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return NotFound();

            var availability = await _context.Availabilities
                .Include(a => a.Doctor)
                .FirstOrDefaultAsync(a => a.AvailabilityId == id);

            if (availability == null)
                return NotFound();

            return View(availability);
        }

        public IActionResult Create()
        {
            ViewData["DoctorId"] = new SelectList(_context.Doctors, "DoctorId", "Name");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AvailabilityId,DoctorId,Date,StartTime,EndTime")] Availability availability)
        {
            if (ModelState.IsValid)
            {
                _context.Add(availability);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(availability);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var availability = await _context.Availabilities.FindAsync(id);
            if (availability == null)
                return NotFound();

            ViewData["DoctorId"] = new SelectList(_context.Doctors, "DoctorId", "Name", availability.DoctorId);
            return View(availability);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("AvailabilityId,DoctorId,Date,StartTime,EndTime")] Availability availability)
        {
            if (id != availability.AvailabilityId)
                return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(availability);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AvailabilityExists(availability.AvailabilityId))
                        return NotFound();
                    else
                        throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(availability);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var availability = await _context.Availabilities
                .Include(a => a.Doctor)
                .FirstOrDefaultAsync(a => a.AvailabilityId == id);

            if (availability == null)
                return NotFound();

            return View(availability);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var availability = await _context.Availabilities.FindAsync(id);
            if (availability != null)
            {
                _context.Availabilities.Remove(availability);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        private bool AvailabilityExists(int id)
        {
            return _context.Availabilities.Any(a => a.AvailabilityId == id);
        }
    }
}
